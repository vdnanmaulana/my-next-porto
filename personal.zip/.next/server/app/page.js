(() => {
var exports = {};
exports.id = 931;
exports.ids = [931];
exports.modules = {

/***/ 8038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 8704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 7897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 6786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 1844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 6624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 5281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 7085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 9569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 7160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 2336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 7887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 8735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 8231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 3750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 9618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 8423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 1017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 7310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 4291:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport safe */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__.GlobalError),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1240);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9506);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5394);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    

    const tree = {
        children: [
        '',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 8679)), "C:\\Users\\Adnan Maulana\\Desktop\\nextjs\\personal\\app\\page.js"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4169)), "C:\\Users\\Adnan Maulana\\Desktop\\nextjs\\personal\\app\\layout.js"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["C:\\Users\\Adnan Maulana\\Desktop\\nextjs\\personal\\app\\page.js"];

    

    const originalPathname = "/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    

    // Create and export the route module that will be consumed.
    const options = {"definition":{"kind":"APP_PAGE","page":"/page","pathname":"/","bundlePath":"app/page","filename":"","appPaths":[]}}
    const routeModule = new (next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default())({
      ...options,
      userland: {
        loaderTree: tree,
      },
    })
  

/***/ }),

/***/ 6590:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 7120, 23))

/***/ }),

/***/ 8679:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ app_page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/react.shared-subset.js
var react_shared_subset = __webpack_require__(6261);
// EXTERNAL MODULE: ./node_modules/boxicons/css/boxicons.min.css
var boxicons_min = __webpack_require__(5717);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(3219);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./app/components/Header.js



function Header() {
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("header", {
            className: "flex justify-center mt-10 left-[90px] right-[90px]",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex flex-row items-center",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                    className: "flex flex-row border-gray-500 border-2 space-x-8 px-8 py-4 bg-zinc-800 rounded-full",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "text-white transition duration-200 hover:text-[#2DD4BF]",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/",
                                children: "Home"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "text-white transition duration-200 hover:text-[#2DD4BF]",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/about",
                                children: "About"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "text-white transition duration-200 hover:text-[#2DD4BF]",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/",
                                children: "Projects"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "text-white transition duration-200 hover:text-[#2DD4BF]",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/",
                                children: "Uses"
                            })
                        })
                    ]
                })
            })
        })
    });
}
/* harmony default export */ const components_Header = (Header);

;// CONCATENATED MODULE: ./app/components/Hero.js



function hero() {
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "hero",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: " text-white py-28 px-10 md:px-[150px] mx-auto md:mx-0",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        src: "/images/nan.jpg",
                        className: "justify-center h-[100px] rounded-full mx-auto md:mx-0"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "text-center text-2xl md:text-4xl mt-6 font-semibold md:mx-0 md:text-left",
                        children: "Junior web developer"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-center mt-4 leading-8 md:w-2/3 md:text-left",
                        children: "Hello. I’m a Junior Web Developer. I currently learning web development like Laravel, CodeIgniter, and a solid understanding of React."
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-row mt-5 space-x-4 justify-center md:justify-normal",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "https://twitter.com/adnanmaulana__",
                                target: "_blank",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    class: "bx bxl-twitter text-3xl"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "https://instagram.com/pixelmind__",
                                target: "_blank",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    class: "bx bxl-instagram text-3xl"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "https://github.com/vdnanmaulana",
                                target: "_blank",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    class: "bx bxl-github text-3xl"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "https://dribbble.com/adnanmaulana",
                                target: "_blank",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    class: "bx bxl-dribbble text-3xl"
                                })
                            })
                        ]
                    })
                ]
            })
        })
    });
}
/* harmony default export */ const Hero = (hero);

;// CONCATENATED MODULE: ./app/components/Gallery.js


function Gallery() {
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "gallery mx-10 mb-10",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-row overflow-x-auto py-5 px-5 space-x-10 text-white justify-center",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        className: "rounded-[16px] w-[300px] h-[300px] rotate-3 object-cover",
                        src: "/images/img1.jpg"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        className: "rounded-[16px] w-[300px] h-[300px] rotate-[-5deg] object-cover",
                        src: "/images/img2.jpg"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        className: "rounded-[16px] w-[300px] h-[300px] rotate-[2deg] object-cover",
                        src: "/images/img3.jpg"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        className: "rounded-[16px] w-[300px] h-[300px] rotate-[-3deg] object-cover",
                        src: "/images/img4.jpg"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        className: "rounded-[16px] w-[300px] h-[300px] rotate-[7deg] object-cover",
                        src: "/images/img5.jpg"
                    })
                ]
            })
        })
    });
}
/* harmony default export */ const components_Gallery = (Gallery);

;// CONCATENATED MODULE: ./app/page.js






function page() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(components_Header, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
                className: "main",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Hero, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(components_Gallery, {})
                ]
            })
        ]
    });
}
/* harmony default export */ const app_page = (page);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [669,716,90,253], () => (__webpack_exec__(4291)));
module.exports = __webpack_exports__;

})();