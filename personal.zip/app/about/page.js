import React from "react";

function page() {
  return <></>;
}

export default page;
